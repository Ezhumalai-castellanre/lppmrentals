const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

const s3Client = new S3Client({
  region: process.env.AWS_REGION || 'us-east-1',
});

// CORS headers helper function
const getCorsHeaders = () => ({
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, X-Amz-Date, Authorization, X-Api-Key, X-Amz-Security-Token, Origin, Accept',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Credentials': 'true'
});

exports.handler = async (event) => {
  console.log('🔍 Event received:', JSON.stringify(event, null, 2));
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    console.log('✅ Handling CORS preflight request');
    return {
      statusCode: 200,
      headers: getCorsHeaders(),
      body: ''
    };
  }

  try {
    if (event.httpMethod !== 'POST') {
      console.log('❌ Method not allowed:', event.httpMethod);
      return {
        statusCode: 405,
        headers: {
          'Content-Type': 'application/json',
          ...getCorsHeaders()
        },
        body: JSON.stringify({ error: 'Method not allowed', message: 'Only POST requests are supported' })
      };
    }

    console.log('📝 Parsing request body...');
    const body = JSON.parse(event.body);
    const { fileName, fileType, referenceId, sectionName, zoneinfo, documentName } = body;

    console.log('🔍 Request parameters:', { fileName, fileType, referenceId, sectionName, zoneinfo, documentName });

    if (!fileName || !fileType || !referenceId || !sectionName || !zoneinfo) {
      console.log('❌ Missing required fields');
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          ...getCorsHeaders()
        },
        body: JSON.stringify({ error: 'Missing required fields', message: 'fileName, fileType, referenceId, sectionName, and zoneinfo are required' })
      };
    }

    const bucketName = process.env.AWS_S3_BUCKET_NAME || 'supportingdocuments-storage-2025';
    console.log('🪣 Using S3 bucket:', bucketName);
    
    const timestamp = Date.now();
    const safeFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
    const key = `documents/${zoneinfo}/${sectionName}/${documentName || 'default'}/${timestamp}_${safeFileName}`;
    
    console.log('🔑 Generated S3 key:', key);

    const command = new PutObjectCommand({
      Bucket: bucketName,
      Key: key,
      ContentType: fileType
      // Removed ACL and ServerSideEncryption to avoid permission issues
    });

    console.log('🔐 Generating presigned URL...');
    const presignedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 }); // URL valid for 1 hour
    console.log('✅ Presigned URL generated successfully');

    const response = {
      success: true,
      url: presignedUrl,
      key: key,
      cleanUrl: `https://${bucketName}.s3.${process.env.AWS_REGION || 'us-east-1'}.amazonaws.com/${key}`
    };

    console.log('📤 Sending response:', response);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        ...getCorsHeaders()
      },
      body: JSON.stringify(response)
    };

  } catch (error) {
    console.error('❌ S3 presign error:', error);
    console.error('❌ Error stack:', error.stack);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...getCorsHeaders()
      },
      body: JSON.stringify({ 
        success: false,
        error: 'Failed to generate presigned URL', 
        message: error.message,
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
